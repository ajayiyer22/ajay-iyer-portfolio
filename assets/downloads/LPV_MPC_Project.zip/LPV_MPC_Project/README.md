# LPV-MPC vehicle project: source and reproduction

These two Python files are the supplied project files, preserved without changes. They credit Mark Misin and retain his original copyright and permission terms. Ajay Iyer used the reference theory in his graduate LPV-MPC project; inclusion here does not claim original authorship of the reference code.

Run MAIN_MPC_car_general.py with Python, numpy, matplotlib, scipy, qpsolvers, and cvxopt. The portfolio figures replay the supplied default trajectory 3, version 2, for 154 simulation seconds (7,701 samples). render_results.py runs the same numerical loop and creates the figures without opening the interactive animation. The source model and controller were not modified for this replay.

Measured replay results are in results.json. These are simulated tracking results, not physical-vehicle validation or a real-time benchmark. The position error is sqrt((X-X_ref)^2+(Y-Y_ref)^2) for each sample; position RMSE is sqrt(mean(error^2)).

Reference copyright: © Mark Misin Engineering. Keep the original notices and attribution with any redistribution.
