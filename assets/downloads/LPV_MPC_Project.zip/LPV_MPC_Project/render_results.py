from pathlib import Path
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import numpy as np
source=Path('MAIN_MPC_car_general.py').read_text().split('################################ ANIMATION LOOP')[0]
ns={}
exec(compile(source,'MAIN_MPC_car_general.py','exec'),ns)
states=ns['statesTotal'];ref=np.column_stack([ns['X_ref'],ns['Y_ref']]);t=ns['t'];inputs=ns['UTotal']
assert np.isfinite(states).all(), 'Non-finite states'
assert ns['i']==ns['sim_length']-2, 'Incomplete simulation'
error=np.linalg.norm(states[:,4:6]-ref,axis=1)
np.savez('simulation.npz',states=states,reference=ref,time=t,inputs=inputs)
plt.rcParams.update({'font.family':'DejaVu Sans','font.size':11,'axes.spines.top':False,'axes.spines.right':False})
fig,ax=plt.subplots(figsize=(9,6))
ax.plot(ref[:,0],ref[:,1],color='#ac533e',lw=2.5,label='Reference')
ax.plot(states[:,4],states[:,5],color='#164f42',lw=1.7,ls='--',label='Simulated vehicle')
ax.set(xlabel='X position (m)',ylabel='Y position (m)',title='LPV-MPC · Circuit trajectory tracking');ax.set_aspect('equal',adjustable='datalim');ax.legend();ax.grid(alpha=.18)
fig.text(.12,.025,'Reference implementation: © Mark Misin Engineering · Project replay, October 2026',fontsize=8,color='#52625e')
fig.tight_layout(rect=[0,.055,1,1]);fig.savefig('mpc-tracking.png',dpi=170);plt.close(fig)
fig,ax=plt.subplots(3,1,figsize=(9,8),sharex=True)
ax[0].plot(t,error,color='#164f42');ax[0].set(ylabel='Position error (m)',title='LPV-MPC · Simulated tracking error and inputs')
ax[1].plot(t,np.degrees(inputs[:,0]),color='#164f42');ax[1].axhline(30,color='#ac533e',ls='--',lw=1);ax[1].axhline(-30,color='#ac533e',ls='--',lw=1);ax[1].set(ylabel='Steering (degrees)')
ax[2].plot(t,inputs[:,1],color='#164f42');ax[2].set(ylabel='Acceleration input (m/s²)',xlabel='Simulation time (s)')
for a in ax:a.grid(alpha=.18)
fig.text(.13,.015,'Reference implementation: © Mark Misin Engineering · Project replay, October 2026',fontsize=8,color='#52625e')
fig.tight_layout(rect=[0,.04,1,1]);fig.savefig('mpc-inputs.png',dpi=170)
import json
Path('results.json').write_text(json.dumps({'trajectory':int(ns['trajectory']),'simulation_seconds':float(t[-1]),'samples':len(t),'position_rmse_m':float(np.sqrt(np.mean(error**2))),'max_position_error_m':float(error.max()),'max_abs_steering_deg':float(np.abs(np.degrees(inputs[:,0])).max())},indent=2))
print(Path('results.json').read_text())
